#!/usr/bin/env python3
import json
import sys
import random
from typing import Set, List, Dict

def load_questions_from_file(file_path: str) -> Set[str]:
    """Load questions from a JSON file and return as a set."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        questions = set()
        if isinstance(data, list):
            for item in data:
                if isinstance(item, dict) and 'question' in item:
                    questions.add(item['question'])
        elif isinstance(data, dict) and 'question' in data:
            questions.add(data['question'])
        
        return questions
    
    except Exception as e:
        print(f"Error loading {file_path}: {e}")
        return set()

def sample_non_matching_questions(wiki_file: str, exclude_file: str, num_samples: int) -> List[Dict]:
    """Sample questions from wiki file that don't match questions in exclude file."""
    
    # Load questions to exclude
    print(f"Loading questions to exclude from {exclude_file}...")
    exclude_questions = load_questions_from_file(exclude_file)
    print(f"Found {len(exclude_questions):,} questions to exclude")
    
    # Load wiki corpus
    print(f"Loading wiki corpus from {wiki_file}...")
    try:
        with open(wiki_file, 'r', encoding='utf-8') as f:
            wiki_data = json.load(f)
    except Exception as e:
        print(f"Error loading wiki file: {e}")
        return []
    
    if not isinstance(wiki_data, list):
        print("Error: Wiki file should contain a list of items")
        return []
    
    print(f"Wiki corpus contains {len(wiki_data):,} items")
    
    # Filter out matching questions
    non_matching_items = []
    for item in wiki_data:
        if isinstance(item, dict) and 'question' in item:
            if item['question'] not in exclude_questions:
                non_matching_items.append(item)
    
    print(f"Found {len(non_matching_items):,} non-matching items")
    
    # Check if we have enough samples
    if len(non_matching_items) < num_samples:
        print(f"Warning: Only {len(non_matching_items)} non-matching items available, less than requested {num_samples}")
        num_samples = len(non_matching_items)
    
    # Sample randomly
    sampled_items = random.sample(non_matching_items, num_samples)
    print(f"Sampled {len(sampled_items):,} items")
    
    return sampled_items

def main():
    if len(sys.argv) != 3:
        print("Usage: python sample_non_matching.py <num_samples> <exclude_json_file>")
        print("Example: python sample_non_matching.py 1000 ../collected_datasets/hallucination_dataset.json")
        print()
        print("This script samples from wiki_ml_corpus_extracted.json")
        print("excluding any questions that match those in the provided JSON file.")
        return
    
    try:
        num_samples = int(sys.argv[1])
        exclude_file = sys.argv[2]
    except ValueError:
        print("Error: First argument must be a number")
        return
    
    if num_samples <= 0:
        print("Error: Number of samples must be positive")
        return
    
    wiki_file = "wiki_ml_corpus_extracted.json"
    
    # Sample non-matching questions
    sampled_items = sample_non_matching_questions(wiki_file, exclude_file, num_samples)
    
    if not sampled_items:
        print("No samples generated")
        return
    
    # Generate output filename
    exclude_filename = exclude_file.split('/')[-1].replace('.json', '')
    output_file = f"sampled_{num_samples}_non_matching_{exclude_filename}.json"
    
    # Save sampled data
    try:
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(sampled_items, f, indent=2, ensure_ascii=False)
        print(f"✓ Saved {len(sampled_items):,} samples to {output_file}")
    except Exception as e:
        print(f"Error saving output file: {e}")

if __name__ == "__main__":
    main()